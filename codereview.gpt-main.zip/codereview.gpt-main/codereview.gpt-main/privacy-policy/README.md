# Privacy Policy for codereview.gpt

No data or personal information is collected by [this Chrome extensions](https://chrome.google.com/webstore/detail/codereviewgpt/amdfidcajdihmbhmmgohhkoaijpkocdn).

##### Contact

If you have any questions or suggestions regarding this privacy policy, do not hesitate to [contact me](https://github.com/sturdy-dev/codereview.gpt/issues).
