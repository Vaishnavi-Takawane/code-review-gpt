

No data or personal information is collected by [this Chrome extensions]