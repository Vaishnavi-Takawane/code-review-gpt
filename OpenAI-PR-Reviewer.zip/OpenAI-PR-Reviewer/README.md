# OpenAI-PR-Reviewer

<p align='center'>
    Review GitHub Pull Requests using <a href="https://chat.openai.com" target="_blank">ChatGPT</a>.
</p>

<p align="center">
  <a href="#overview">🔍 Overview</a> •
  <a href="#usage">💻 Usage</a> •
  <a href="#installation">🔧 Installation</a>
</p>

## Overview

This is a Chrome extension which reviews Pull Requests for you using [ChatGPT](https://chat.openai.com/).

## Usage

- Navigate to a GitHub Pull Request that you want a review for.
- Fill in your [OpenAI API token](https://platform.openai.com/account/api-keys) in the Settings of the Chrome Extension
- Click the extension icon
- You get code review comments from ChatGPT in the popup window

**NB:** Running the review multiple times often produces different feedback, so if you are dealing with a larger PR, it might be a good idea to do that to get the most out of it.

## Installation

- Clone this repository `git clone foo && cd foo`
- Install the dependencies `npm install`
- Run the build script `npm run build`
- Navigate to `chrome://extensions`
- Enable Developer Mode
- Click the 'Load unpacked' button and navigate to the `build` directory in the project

## Supported browsers

only Chrome is supported

## Permissions

This is a list of permissions the extension uses with the respective reason.

- `activeTab` is used to get the URL or the active tab. This is needed to fetch the get the Pull Request details
- `storage` is used to cache the responses from OpenAI
- `scripting` is used to fetch html content from the Pull Request

https://hsbc.zoom.us/j/91515328030?pwd=eTVualNiaVpHdlJ4ejdBTHhzTnhwUT09
npm install --save react-copy-to-clipboard
